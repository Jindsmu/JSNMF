%% Load the real input data
clc
clear
close all
X1 = csvread('WSI.csv');
X2 = csvread('gene.csv');
X3 = csvread('pathway.csv');

labs = csvread('sarcoma_label.csv');

nnClass = length(unique(labs));
% Perform Min-Max normalization on X1 (scale each row to [0,1] interval)
X1_min = min(X1, [], 2);
X1_max = max(X1, [], 2);
X1_range = X1_max - X1_min;
X1_range(X1_range < eps) = 1;  % Prevent division by zero (handle all-zero rows)
X1 = (X1 - X1_min) ./ X1_range;

% Perform the same processing on X2
X2_min = min(X2, [], 2);
X2_max = max(X2, [], 2);
X2_range = X2_max - X2_min;
X2_range(X2_range < eps) = 1;
X2 = (X2 - X2_min) ./ X2_range;

% Perform the same processing on X3
X3_min = min(X3, [], 2);
X3_max = max(X3, [], 2);
X3_range = X3_max - X3_min;
X3_range(X3_range < eps) = 1;
X3 = (X3 - X3_min) ./ X3_range;
X1 = X1 ./ repmat(sqrt(sum(X1.^2, 2)), 1, size(X1, 2));
X2 = X2 ./ repmat(sqrt(sum(X2.^2, 2)), 1, size(X2, 2));
X3 = X3 ./ repmat(sqrt(sum(X3.^2, 2)), 1, size(X3, 2));
rows1 = size(X1, 2);
rows2 = size(X2, 2);
rows3 = size(X3, 2);
% getdata;0
alp = 0.1; beta = 0.01; K = 15; alpha = 0.3;
Dist1 = dist2(X1, X1);
Dist2 = dist2(X2, X2);
Dist3 = dist2(X3, X3);

%%% Next, construct similarity graphs
W1 = affinityMatrix(Dist1, K, alpha);
W2 = affinityMatrix(Dist2, K, alpha);
W3 = affinityMatrix(Dist3, K, alpha);
[n, m1] = size(X1);

% Next, we fuse all the graphs
% Then the overall matrix can be computed by similarity network fusion(SNF):
W_snf = SNF({W1, W2, W3}, K, 20);
% Get factors by applying multi-cNMF algorithm

%% Find optimal parameter combination
% min_error = inf;  % Initialize to infinity
% best_alp = 0;
% best_beta = 0;
% best_K = 0;
% 
% alp_values = [0.01, 0.1, 1, 10];
% beta_values = [0.01, 0.1, 1, 10];
% K_values = [5, 10, 15, 20];
% 
% % Table to store all results
% results = table('Size', [length(alp_values)*length(beta_values)*length(K_values), 5], ...
%                 'VariableTypes', {'double', 'double', 'double', 'double', 'logical'}, ...
%                 'VariableNames', {'alp', 'beta', 'K', 'errorx', 'is_best'});
% row_idx = 1;
% 
% % Iterate through parameter combinations
% for i = 1:length(alp_values)
%     alp = alp_values(i);
%     for j = 1:length(beta_values)
%         beta = beta_values(j);
%         for k = 1:length(K_values)
%             K = K_values(k);
% 
%             % Perform PCA and NMF
%             [W_PCA, COEFF, sum_explained] = pca_demo_1(W_snf, K);
%             R = W_PCA;
%             [W, H1, H2, H3] = multi_cNMF(X1, X2, X3, R, alp, beta, K);
% 
%             % Calculate error
%             errorx1 = mean(mean(abs(X1 - W*H1))) / mean(mean(X1));
%             errorx2 = mean(mean(abs(X2 - W*H2))) / mean(mean(X2));
%             errorx3 = mean(mean(abs(X3 - W*H3))) / mean(mean(X3));
%             errorx = errorx1 + errorx2 + errorx3;
% 
%             % Record results
%             results(row_idx, :) = {alp, beta, K, errorx, false};
%             row_idx = row_idx + 1;
% 
%             % Update optimal parameters
%             if errorx < min_error
%                 min_error = errorx;
%                 best_alp = alp;
%                 best_beta = beta;
%                 best_K = K;
%             end
%         end
%     end
% end
% 
% % Mark the optimal parameter combination
% best_idx = find(results.errorx == min_error, 1);
% results.is_best(best_idx) = true;
% 
% % Display optimal results
% fprintf('Optimal parameter combination: alp=%.4f, beta=%.4f, K=%d\n', best_alp, best_beta, best_K);
% fprintf('Minimum error: errorx=%.6f\n', min_error);
% 

%% Run JSNMF with optimal parameters
% Optimal parameter combination: alp=0.0100, beta=0.0100, K=20

tic
alp = 0.01; beta = 0.01; K = 20;
[W_PCA, COEFF, sum_explained] = pca_demo_1(W_snf, K);
R = W_PCA;
[W, H1, H2, H3] = JSNMF(X1, X2, X3, R, alp, beta, K);
toc
XX1 = W * H1;
XX2 = W * H2;
XX3 = W * H3;
% Calculate correlation coefficients (your original code)
for i = 1:n
    cor11(i,1) = corr(X1(i,1:rows1)', XX1(i,1:rows1)');
    cor12(i,1) = corr(X2(i,1:rows2)', XX2(i,1:rows2)');
    cor13(i,1) = corr(X3(i,1:rows3)', XX3(i,1:rows3)');
end

% Calculate average correlation coefficients (your original code)
mean_cor11 = mean(cor11);
mean_cor12 = mean(cor12);
mean_cor13 = mean(cor13);

% Fisher Z transformation to calculate confidence intervals
alpha = 0.05;  % Significance level for 95% confidence interval
z_critical = norminv(1-alpha/2);  % Critical value from standard normal distribution

% Calculate confidence intervals for each correlation coefficient vector
% 1. Fisher Z transformation of correlation coefficients
z_cor11 = 0.5 * log((1 + cor11) ./ (1 - cor11));
z_cor12 = 0.5 * log((1 + cor12) ./ (1 - cor12));
z_cor13 = 0.5 * log((1 + cor13) ./ (1 - cor13));

% 2. Calculate mean and standard error after Z transformation
mean_z11 = mean(z_cor11);
mean_z12 = mean(z_cor12);
mean_z13 = mean(z_cor13);

se_z11 = 1 / sqrt(n - 3);  % Standard error
se_z12 = 1 / sqrt(n - 3);
se_z13 = 1 / sqrt(n - 3);

% 3. Calculate confidence intervals after Z transformation
z_ci_lower11 = mean_z11 - z_critical * se_z11;
z_ci_upper11 = mean_z11 + z_critical * se_z11;
z_ci_lower12 = mean_z12 - z_critical * se_z12;
z_ci_upper12 = mean_z12 + z_critical * se_z12;
z_ci_lower13 = mean_z13 - z_critical * se_z13;
z_ci_upper13 = mean_z13 + z_critical * se_z13;

% 4. Convert Z-transformed confidence intervals back to correlation coefficient space
ci_lower11 = tanh(z_ci_lower11);
ci_upper11 = tanh(z_ci_upper11);
ci_lower12 = tanh(z_ci_lower12);
ci_upper12 = tanh(z_ci_upper12);
ci_lower13 = tanh(z_ci_lower13);
ci_upper13 = tanh(z_ci_upper13);

% Display results
fprintf('Average correlation coefficient for cor11: %.3f (95%% CI: %.3f, %.3f)\n', mean_cor11, ci_lower11, ci_upper11);
fprintf('Average correlation coefficient for cor12: %.3f (95%% CI: %.3f, %.3f)\n', mean_cor12, ci_lower12, ci_upper12);
fprintf('Average correlation coefficient for cor13: %.3f (95%% CI: %.3f, %.3f)\n', mean_cor13, ci_lower13, ci_upper13);


% Output H1, H2, H3 to Excel file
% Create table objects
T1 = array2table(H1);
T2 = array2table(H2);
T3 = array2table(H3);
T4 = array2table(W);
% Calculate Pearson correlation coefficients for each column with labels
[R, P] = corrcoef([W, labs]);  % Combine data and labels to calculate correlation matrix

% Extract correlation coefficients between first 10 columns (features) and 11th column (labels)
corr_coeffs = R(1:K, K+1);

% Find the maximum absolute value of correlation coefficient and corresponding column index (column is feature dimension)
[max_corr, col_idx] = max(abs(corr_coeffs));  % Maximum absolute value, avoid ignoring negative correlations
original_sign = sign(corr_coeffs(col_idx));     % Preserve original sign

% Output results (column index corresponds to column col_idx of W)
fprintf('Maximum Pearson correlation coefficient (absolute value): %.4f\n', max_corr * original_sign);
fprintf('Corresponds to column %d of W (feature dimension)\n', col_idx);
% % Write to Excel file
% writetable(T1, 'JSNMF_sarcoma.xlsx', 'Sheet', 'H1');
% writetable(T2, 'JSNMF_sarcoma.xlsx', 'Sheet', 'H2');
% writetable(T3, 'JSNMF_sarcoma.xlsx', 'Sheet', 'H3');
% writetable(T4, 'JSNMF_sarcoma.xlsx', 'Sheet', 'W');
%% Define output file names
% filename_XX1 = 'reconstructed_XX1.csv';
% filename_XX2 = 'reconstructed_XX2.csv';
% filename_XX3 = 'reconstructed_XX3.csv';
% 
% % Export XX1
% writematrix(XX1, filename_XX1);  % Export by default as matrix dimension (number of samples �� number of features)
% 
% % Export XX2
% writematrix(XX2, filename_XX2);
% 
% % Export XX3
% writematrix(XX3, filename_XX3);
% 
% disp('Reconstructed matrices successfully saved as CSV files!');
% 