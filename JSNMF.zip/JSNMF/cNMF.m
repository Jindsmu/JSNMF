function [W,H1,H2,H3,errorx1,errorx2,errorx3,errorx] = cNMF(X1, X2, X3, R, alp, beta, K, maxiter, speak, fid)

% Multiple NMF using euclidean distance update equations:
%
% Lee, D..D., and Seung, H.S., (2001), 'Algorithms for Non-negative Matrix
% Factorization', Adv. Neural Info. Proc. Syst. 13, 556-562.
%
% INPUT:
% X1 (N,M1): N (dimensionallity) x M1 (feature 1) non negative input matrix
% X2 (N,M2): N (dimensionallity) x M2 (feature 2) non negative input matrix
% A (M2,M2): M1 x M2, non negative input matrix
% r1       : limit the growth of W
% r2       : limit the growth of H1 H2 and H3
% L       : weigh the must link constraints in A
% K        : Number of components
% maxiter  : Maximum number of iterations to run
% speak    : prints iteration count and changes in connectivity matrix 
%            elements unless speak is 0
%fid       : file identifier which is used to store the changes record

% OUTPUT:
% W        : N x K matrix
% H1       : K x M1 matrix
% H2       : K x M2 matrix

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% User adjustable parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

print_iter = 5; % iterations between print on screen and convergence test

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test for negative values in X1 and X2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (min(min(X1)) < 0) || (min(min(X2)) < 0)|| (min(min(X3)) < 0)
    error('Input matrix elements can not be negative');
    return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test for same rows in X1 and X2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[n1,m1] = size(X1);
[n2,m2] = size(X2);
[n3,m3] = size(X3);

if (n1 ~= n2 || n1 ~= n3)
    error('Input matrices should have the same rows');
end
n = n1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialize random W, H1 H2 H3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
X = [X1 X2 X3];
[U,S,V]=svd(X);
s_sum = sum(S); 
W(:,1) = sqrt(S(1,1))*U(:,1);
H(1,:) = sqrt(S(1,1))*V(:,1)';
for j = 2 : K
    x = U(:,j);
    y = V(:,j);
    xp = (x>=0).*x;
    xn = (x<0).*(-x);
    yp = (y>=0).*y;
    yn = (y<0).*(-y);
    xpnrm = norm(xp);
    ypnrm = norm(yp);
    mp = xpnrm * ypnrm;
    xnnrm = norm(xn);
    ynnrm = norm(yn);
    mn = xnnrm * ynnrm;
    if mp > mn
        u = xp/xpnrm;
        v = yp/ypnrm;
        sigma = mp;
    else
        u = xn/xnnrm;
        v = yn/ynnrm;
        sigma = mn;
    end
    W(:,j) = sqrt(S(j,j)*sigma)*u;
    H(j,:) = sqrt(S(j,j)*sigma)*v';
end
W = abs(W);
H = abs(H);
H1 = H(:,1:m1);
H2 = H(:,m1+1:m1+m2);
H3 = H(:,m1+m2+1:m1+m2+m3);
% W = rand(n,K);
% H1 = rand(K,m1);
% H2 = rand(K,m2);
% H3 = rand(K,m3);

% use W*H to test for convergence
Xr_old1 = W*H1;
Xr_old2 = W*H2;
Xr_old3 = W*H3;
W_prev = W;
H1_prev = H1;
H2_prev = H1;
H3_prev = H1;
for iter = 1 : maxiter
    % Euclidean multiplicative method
    W = W.*(alp*R + ([H1 H2 H3]*[X1 X2 X3]')')./(W*(([H1 H2 H3]*[H1 H2 H3]'+alp*eye(K))+eps));    %Update rule-1;   
  %eye(k)���ɶԽǾ���
    HH1 = H1.*(W'*X1)./((W'*W+beta*(H1*H1'-ones(K)))*H1+eps);     %%Update H
    HH2 = H2.*(W'*X2)./((W'*W+beta*(H2*H2'-ones(K)))*H2+eps);
    HH3 = H3.*(W'*X3)./((W'*W+beta*(H3*H3'-ones(K)))*H3+eps);
    H1 = HH1;
    H2 = HH2;
    H3 = HH3;
    if iter > 1
        % ����ŷ�Ͼ��� (��������Ԫ�ز��ƽ���͵�ƽ����)
        diff_W = norm(W - W_prev, 'fro');
        diff_H1 = norm(H1 - H1_prev, 'fro');
        diff_H2 = norm(H2 - H2_prev, 'fro');
        diff_H3 = norm(H3 - H3_prev, 'fro');
    end
    
    % ������һ�ε�W����
    W_prev = W;
    H1_prev = H1;
    H2_prev = H2;
    H3_prev = H3;
   % iter
    % print to screen
    if (rem(iter,print_iter) == 0) & speak  %iter����print_iter������Ϊ0��speakΪ1
        Xr1 = W*H1+eps;            
        Xr2 = W*H2+eps;
        Xr3 = W*H3+eps;
        diff_step = sum(sum(abs(Xr_old1-Xr1)))+sum(sum(abs(Xr_old2-Xr2)))+sum(sum(abs(Xr_old3-Xr3)));
        
        % %diff2 = -L*trace(H1*A*H2');  %trace���ά����ļ�(����Խ���֮��)
        % diff_W = sum(sum(W.*W));    %sum���к�,����sum�൱��������Ԫ��֮��
	    % diff_H = ((sum(sum(H1).^2)+sum(sum(H2).^2))+sum(sum(H3).^2));
       
	    Xr_old1 = Xr1;
        Xr_old2 = Xr2;
        Xr_old3 = Xr3;
        
        eucl_dist1 = nmf_euclidean_dist(X1,W*H1);
        eucl_dist2 = nmf_euclidean_dist(X2,W*H2);
        eucl_dist3 = nmf_euclidean_dist(X3,W*H3);
        eucl_dist = eucl_dist1 + eucl_dist2 + eucl_dist3;

        errorx1 = mean(mean(abs(X1-W*H1)))/mean(mean(X1));
        errorx2 = mean(mean(abs(X2-W*H2)))/mean(mean(X2));
        errorx3 = mean(mean(abs(X3-W*H3)))/mean(mean(X3));
        errorx = errorx1 + errorx2 + errorx3;
        disp(['Iter = ',int2str(iter),...
            ', relative error = ',num2str(errorx),...
            ', diff = ', num2str(diff_step),...
            ', eucl dist ' num2str(eucl_dist) ...
            ', diff_W ' num2str(diff_W) ...
            ', diff_H1 ' num2str(diff_H1) ...
            ', diff_H2 ' num2str(diff_H2) ...
            ', diff_H3 ' num2str(diff_H3)])
        if errorx < 10^(-5), break, end
    end
end

function err = nmf_euclidean_dist(X,Y)
err = sum(sum((X-Y).^2));


