function [W,H1,H2,H3] = JSNMF(X1, X2, X3, R, alp, beta, K)
%
% INPUT:
% X1 (N,M1): input profile matrix
% X2 (N,M2): input profile matrix
% A (M1,M2): input adjacent matrix
%%% C (M3,M2): input adjacent matrix
% r1       : limit the growth of W
% r2       : limit the growth of H1 and H2
% L       : weigh the must link constraints in B
% K        : Number of components
%
% avoid this kind of column or row: sum == 0
index = find(sum(X1,1) == 0);
X1(:,index) = X1(:,index) + eps;

index = find(sum(X2,1) == 0);
X2(:,index) = X2(:,index) + eps;

index = find(sum(X3,1) == 0);
X3(:,index) = X3(:,index) + eps;
%index = find(sum(A,1) == 0);
%A(:,index) = A(:,index) + eps;  %�����к��еĺ�Ϊ0������eps��һ����С����

% set the iteration number and initiate the output matrices�����õ��������������������
nloop = 1; 
verbose=1;

[n,m1] = size(X1);
[n,m2] = size(X2);
[n,m3] = size(X3);

bestW=zeros(n,K);
bestH1=zeros(K,m1);
bestH2=zeros(K,m2);
bestH3=zeros(K,m3);

bestobj1=1000000000000000000000;
bestobj2=1000000000000000000000;
bestobj3=1000000000000000000000;
maxiter=500; 

fid = fopen(['new_record_K' int2str(K)   '_alp=' num2str(alp) '_beta=' num2str(beta) '_maxiter=' int2str(maxiter) '.txt'],'wt+');
for iloop=1:nloop
    if verbose 
        fprintf(fid,' iteration %d\n',iloop); 
    end    

    speak=1; 
    [W,H1,H2,H3,errorx1,errorx2,errorx3,errorx]=cNMF(X1, X2, X3, R, alp, beta, K, maxiter, speak, fid);
    % compute residue
    newobj1 = sum(sum((X1-W*H1).^2));
    newobj2 = sum(sum((X2-W*H2).^2));
    newobj3 = sum(sum((X3-W*H3).^2));
    
    if (newobj1<bestobj1)||(newobj2<bestobj2)||(newobj3<bestobj3)
        bestobj1 = newobj1;
        bestobj2 = newobj2;
        bestobj3 = newobj3;
        bestW = W;
        bestH1 = H1;
        bestH2 = H2;
        bestH3 = H3;
    end
end
fclose(fid);
%  compute the modules according to bestW, bestH1 bestH2 and bestH3
W = bestW; H1 = bestH1; H2 = bestH2; H3 = bestH3;

% �����ع����
reconstruction_error = mean(mean(abs(X1 - W*H1))) + ...
                       mean(mean(abs(X2 - W*H2))) + ...
                       mean(mean(abs(X3 - W*H3)));

% ����Ŀ�꺯��ֵ
objective_function_value = sum([norm(X1 - W*H1,'fro')^2, norm(X2 - W*H2,'fro')^2, norm(X3 - W*H3,'fro')^2]) +...
    beta * sum([norm(H1*H1' - eye(size(H1,1)),'fro')^2, norm(H2*H2' - eye(size(H2,1)),'fro')^2, norm(H3*H3' - eye(size(H3,1)),'fro')^2]) +...
    alp * norm(W - R,'fro')^2;


% ��ӡ�����������
fprintf('Reconstruction Error: %.4f\n', reconstruction_error);
fprintf('Objective Function Value: %.4f\n', objective_function_value);
fprintf('Error1: %.4f\n', errorx1);
fprintf('Error2: %.4f\n', errorx2);
fprintf('Error3: %.4f\n', errorx3);
fprintf('Error: %.4f\n', errorx);